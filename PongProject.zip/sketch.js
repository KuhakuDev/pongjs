//Variaveis da Bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 20;
let raio = diametro / 2;

//Valocidade da bolinha
let velocidadeXBolinha = 8;
let velocidadeyBolinha = 8;

//Variaveis da Raquete
xRaquete = 5;
yRaquete = 150;
raqueteComprimento = 10;
raqueteAltura = 90;

//variáveis oponente
let xRaqueteOponente = 585;
let yRaqueteOponente = 150;
let velocidadeYOponente;

//Placar do Jogo
let meusPontos = 0;
let pontosOponente = 0;


let colidiu = false;

//Sons do jogo
let raquetada;
let ponto;
let trilha;

function preload(){
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}

function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  background(0);
  mostraBolinha();
  movimentaBolinha();
  verificaColisaoBorda();
  mostraRaquete(xRaquete, yRaquete);
  movimentaMinhaRaquete();
  //verificaColisaoRaquete();
  verificaColisaoRaquete(xRaquete, yRaquete);
  mostraRaquete(xRaqueteOponente, yRaqueteOponente);
  movimentaRaqueteOponente();
  verificaColisaoRaquete(xRaqueteOponente, yRaqueteOponente);
  placar();
  marcaPonto();
  bolinhaNaoFicaPresa();
  
  

}

function mostraBolinha(){
  circle(xBolinha, yBolinha, diametro)
  
}

function movimentaBolinha(){
  xBolinha = xBolinha += velocidadeXBolinha;
  yBolinha = yBolinha += velocidadeyBolinha;
}

function verificaColisaoBorda(){
    if (xBolinha + raio > width ||
     xBolinha - raio < 0){
  velocidadeXBolinha *= -1;
}
  
  if (yBolinha + raio > height ||
     yBolinha - raio < 0){
    velocidadeyBolinha *= -1;
  }  
  
}

function mostraRaquete(x, y){
    rect(x, y, raqueteComprimento, raqueteAltura);
  }

function movimentaMinhaRaquete(){
  if (keyIsDown(UP_ARROW)){
    yRaquete -=5;
  }
  if (keyIsDown(DOWN_ARROW)){
    yRaquete +=5;} 
}


function verificaColisaoRaquete(x, y){
  colidiu =
  collideRectCircle(x, y, raqueteComprimento, raqueteAltura, xBolinha, yBolinha, raio);
  if (colidiu){
    velocidadeXBolinha *= -1;
    raquetada.play();
    
  }
}

function movimentaRaqueteOponente(){
 velocidadeYOponente = yBolinha -yRaqueteOponente - raqueteComprimento /2 -30;
  yRaqueteOponente += velocidadeYOponente
}

function placar(){
  stroke(255)
  textAlign(CENTER)
  textSize(16)
  fill(255, 140, 0)
  rect(150, 10, 40, 20)
  fill(255)
  text(meusPontos, 170, 26);
  fill(255, 140, 0)
  rect(450, 10, 40, 20)
  fill(255)
  text(pontosOponente, 470, 26);
}

function marcaPonto(){
  if (xBolinha > 590){
    meusPontos +=1
    ponto.play();
  }
    if(xBolinha < 10){
      pontosOponente +=1
    ponto.play()
    }

}


function bolinhaNaoFicaPresa(){
    if (xBolinha - raio < 0){
    xBolinha = 23
    }
}

